//2
var a = 5;
var b = 5;
var c = 5;
console.log(a, b, c);
a = 6;
b = 7;
c = 8;
console.log(a, b, c);

//3
var a;
console.log(a);
a = true;
console.log(a);
a = 55;
console.log(a);
a = "myName";
console.log(a);
a = null;
console.log(a);
typeof a;

//4
let language = "JavaScript";
var study = "courses";
result = language + " " + study;
console.log(result);

//5
var a;
++a;
++a;
++a;
a = x = z = 5;

//6
var Num = 77;
String(Num);
Boolean(Num);
Number(Num);

